import { Component, OnInit, Inject } from '@angular/core';
import { Categories } from '../service/categories/categories';
import { CategoriesService } from '../service/categories/categories.service';
import { appConfig } from '../service/valueProvider/app.config';
import { IValueProvider } from '../service/valueProvider/ivalue.interface';


@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categories: Categories = new Categories();
  constructor(private catService: CategoriesService,
  @Inject(appConfig) private config: IValueProvider) { }

  ngOnInit() {
    console.log(this.config);
  }
  save(catForm) {
    this.catService.addCategories(this.categories);
    //console.log(this.categories);
    //catForm.reset();
  }

}
