import { InjectionToken } from '@angular/core';
import { IValueProvider, Color } from './ivalue.interface';
export let appConfig = new InjectionToken<IValueProvider>('app.config');

export const APPVALUES: IValueProvider ={
    pageOptions: [10, 20, 30],
    pageSize: 20,
    color: Color.blue 
} 