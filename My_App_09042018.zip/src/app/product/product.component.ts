import { Component, OnInit, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { Product } from './../service/product/product';
import { ProductDetailsComponent } from './product-details/product-details.component'
import { ProductService } from '../service/product/product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  productName: string = '30 inch LED TV';
  isVisible: boolean = false;
  userRole: string = "admin"
  messageFromChild: string;
  @ViewChild(ProductDetailsComponent) prodDetailsComponent: ProductDetailsComponent;
  @ViewChildren(ProductDetailsComponent) ProdChildrenComponent: QueryList<ProductDetailsComponent>;
  productList: Product[];
/*   productList: Product[] = [
    {id: 1, name: 'Lenovo I7 Laptop', price: 30000, mfd: new Date('31-Dec-2015')},
    {id: 2, name: 'Lenovo I6 Laptop', price: 25000, mfd: new Date('31-Dec-2014')},
    {id: 3, name: 'Lenovo I5 Laptop', price: 20000, mfd: new Date('31-Dec-2013')},
    {id: 4, name: 'Lenovo I4 Laptop', price: 15000, mfd: new Date('31-Dec-2012')},
  ]; */
  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.productList = this.productService.getProducts();
  }

  toggle() {
    this.prodDetailsComponent.productName = "My new LED TV";
    this.isVisible = !this.isVisible;
    console.log(this.ProdChildrenComponent);
    this.ProdChildrenComponent.forEach(function(child) {
      child.productName = "My new LED TV";
    })
  }

  receiveFromChild(message: string) {
    this.messageFromChild = message;
  }

}
