import { Component, OnInit } from '@angular/core';
import { TodoService } from '../../service/todo/todo.service';
import { Todo } from '../../service/todo/todo';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {

  todoList: Todo[];
  constructor(private httpService: TodoService) { }

  ngOnInit() {
    console.log(this.httpService.getTodoList());
    this.httpService.getTodoList().subscribe(
      (data) => { this.todoList = data },
      (err) => console.log(err)
    );

    /*this.httpService.getPhotos().subscribe(
      (data) => console.log(data),
      (err) => console.log(err)
    )*/
    this.httpService.getPhotos().subscribe(
      (event) => {
        if (event.type === HttpEventType.DownloadProgress) {
          console.log(event.loaded);
          console.log(event.total);
        } else if (event instanceof HttpResponse) {
          console.log(event.body);
        }
      },
      (err) => console.log(err)
    )
  }

}
