export class Categories {
    id: number;
    name: string;
    description: string;
}