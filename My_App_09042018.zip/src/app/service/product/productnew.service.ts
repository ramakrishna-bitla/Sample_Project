import { Injectable } from '@angular/core';
import { ProductService } from './product.service';

@Injectable()
export class ProductnewService extends ProductService{

  constructor() { 
    super();
  }

  getProducts() {
    return this.productList = [
      {id: 1, name: 'Lenovo I7 Laptop', price: 30000, mfd: new Date('31-Dec-2015')},
      {id: 2, name: 'Lenovo I6 Laptop', price: 25000, mfd: new Date('31-Dec-2014')},
      {id: 3, name: 'Lenovo I5 Laptop', price: 20000, mfd: new Date('31-Dec-2013')},
      {id: 4, name: 'Lenovo I4 Laptop', price: 15000, mfd: new Date('31-Dec-2012')},
      {id: 5, name: 'Lenovo I3 Laptop', price: 12000, mfd: new Date('31-Dec-2011')},
      {id: 6, name: 'Lenovo I2 Laptop', price: 10000, mfd: new Date('31-Dec-2010')},
      {id: 7, name: 'Lenovo I1 Laptop', price: 9000, mfd: new Date('31-Dec-2009')},
    ];
  }

}
