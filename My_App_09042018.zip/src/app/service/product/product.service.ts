import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable()
export class ProductService {
  productList: Product[] = [];
  constructor() { }
  getProducts() {
    return this.productList = [
      {id: 1, name: 'Lenovo I7 Laptop', price: 30000, mfd: new Date('31-Dec-2015')},
      {id: 2, name: 'Lenovo I6 Laptop', price: 25000, mfd: new Date('31-Dec-2014')},
      {id: 3, name: 'Lenovo I5 Laptop', price: 20000, mfd: new Date('31-Dec-2013')},
      {id: 4, name: 'Lenovo I4 Laptop', price: 15000, mfd: new Date('31-Dec-2012')},
      {id: 5, name: 'Lenovo I3 Laptop', price: 12000, mfd: new Date('31-Dec-2011')},
    ];
  }

  addProduct() {
    let product = {id: 6, name: 'Lenovo I3 Laptop', price: 10000, mfd: new Date('31-June-2011')};
    this.productList.push(product);
  }
}
