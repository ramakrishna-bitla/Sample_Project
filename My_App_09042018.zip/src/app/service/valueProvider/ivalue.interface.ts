export interface IValueProvider {
    pageSize: number;
    pageOptions: number[];
    color: Color;
}

export enum Color {
    red,
    green,
    blue
}